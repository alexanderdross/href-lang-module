# Test Execution Report — Drupal + WordPress

Consolidated results for all requested test categories across both platforms.

## Status: the suites now run for real in CI

**Superseding the original note below:** the test suites are executed on every
pull request and push by GitHub Actions
([`.github/workflows/ci.yml`](https://github.com/alexanderdross/href-lang-module/blob/main/.github/workflows/ci.yml)),
on a real PHP 8.3 runtime against a freshly installed Drupal 11. Last green run
on `main` ([29453076587](https://github.com/alexanderdross/href-lang-module/actions/runs/29453076587)):

| Job | Runtime | Result |
|-----|---------|--------|
| `standards` | phpcs (Drupal + DrupalPractice), PHP 8.3 | **0 errors** |
| `wordpress` | PHPUnit 10.5.64 | **OK — 8 tests, 27 assertions** |
| `drupal` | PHPUnit 11.5.56, Drupal 11 + SQLite | **OK — 78 tests, 197 assertions** |

That is **86 tests / 224 assertions passing on real PHP**, with no failures and
no errors. The `drupal` run reports Drupal-11.3 forward-compat deprecations
(`RunTestsInSeparateProcesses`); these are reported but do not gate the merge.
Branch protection on `main` requires all three checks before a PR can merge.

Still requiring a human on a running site: the **manual UAT / security / perf
passes** (`docs/UAT-PLAN.md`, `SECURITY-TEST-PLAN.md`, `PERFORMANCE-TEST-PLAN.md`).

## Environment & method of the original run (historical)

The session that produced this report had **no PHP runtime** (no `php`,
`composer`, `phpunit`, `phpcs`, `phpstan`), so the suites could not be invoked
*there*. “Execution” below therefore means the strongest verification available
at that time — it has since been confirmed by the real CI runs above:

1. **Static verification** — parse every YAML/JSON, check PSR‑4 namespace/class/
   path, resolve every service and route target, verify class references, brace/
   paren balance, `strict_types`, no stray debug, no static `\Drupal::` in DI
   services, plugin loader ↔ file consistency.
2. **Independent algorithm execution** — the core tested algorithms
   (`normalize_code`, `is_valid_code`, `is_absolute`, `clean`, leaf‑slug,
   `cosine`, HMAC canonical) were **re‑implemented in Python and run against the
   exact expected values the unit tests assert**. Matching outputs confirm the
   test expectations are correct, cross‑language.
3. **Assessment** — QA/UAT/best‑practices/security/performance mapped to the
   plan docs and to code‑level guarantees.

To reproduce true runtime execution, see [§Runtime commands](#runtime-commands).

## Summary

| Category | Drupal | WordPress | Basis |
|----------|:------:|:---------:|-------|
| Unit tests | ✅ **run in CI** | ✅ **run in CI** | PHPUnit — 78 / 8 tests green |
| Regression tests | ✅ **run in CI** | ✅ **run in CI** | RegressionTest / SignerTest |
| Kernel tests | ✅ **run in CI** | n/a | Drupal 11 + SQLite |
| Coding standards | ✅ **run in CI** | ✅ **run in CI** | phpcs Drupal+DrupalPractice, 0 errors |
| QA assessment | ✅ | ✅ | QA‑ASSESSMENT.md + inventory |
| UAT assessment | ⏳ manual | ⏳ manual | UAT‑PLAN.md (staging) |
| Best‑practices assessment | ✅ static | ✅ static | BEST‑PRACTICES‑AUDIT.md + checks |
| Security test | ✅ run in CI + logic | ✅ run in CI + logic | SecurityTest / code‑level |
| Performance test | ✅ structural | ✅ structural | PERFORMANCE‑TEST‑PLAN.md |

✅ = passing · ⏳ = requires a running site (manual).
**No failures were found**, in CI or in the static pass.

## Test inventory

| | Drupal | WordPress |
|---|---|---|
| Test files | 21 | 3 (+ standalone bootstrap) |
| Test methods | 54 | 8 |
| Assertions | 167 | 27 |
| Runner | `vendor/bin/phpunit` (Drupal test framework) | `vendor/bin/phpunit` (standalone; no WP needed for the unit suite) |

## Results by category

### 1. Unit tests — ✅
- **Drupal:** `HreflangValidatorTest`, `MappingValidatorTest`, `SlugNormalizerTest`,
  `CosineTest`, `TranslationParseTest`.
- **WordPress:** `ValidatorTest`, `SlugTest`, `SignerTest`.
- **Executed:** re‑derived `normalize_code`, `is_valid_code`, `is_absolute`,
  `clean()`, leaf‑slug, and `cosine()` in Python — **every asserted value
  matches** (30+ cases). Files parse, classes/namespaces correct.

### 2. Regression tests — ✅
- **Drupal `RegressionTest`** locks: CSV export includes confirmed rows,
  `memberIdForUrl` finds confirmed members, empty groups are cleaned.
- **WordPress `SignerTest`** locks the **HMAC canonical contract** (client and
  hub must agree byte‑for‑byte) — re‑derived and matches.
- Structurally valid; fixes documented in `BEST‑PRACTICES‑AUDIT.md §3`.

### 3. QA assessment — ✅
- `drupal/hrefl/docs/QA‑ASSESSMENT.md` present; the coverage inventory it lists
  matches the files on disk (21 Drupal tests verified to exist with correct
  `Drupal\Tests\…` namespaces and `@group`).

### 4. UAT assessment — ⏳ (manual)
- `UAT‑PLAN.md` defines the P1/P2/P3 end‑to‑end scenarios. These require a
  running multi‑site staging environment and cannot be executed here. Plan is
  complete and ready to run; WordPress has its own `SETUP.md` walkthrough that
  doubles as a UAT script.

### 5. Best‑practices assessment — ✅
- **Drupal:** `strict_types` in every `src/` file, no static `\Drupal::` inside
  DI services, PSR‑4 clean for all 75 classes, config schema present, no stray
  debug, update hooks `9001–9004` present.
- **WordPress:** `strict_types` in every file, loader ↔ file consistency (17/17),
  every referenced class defined, `class-*.php` naming convention, nonces on
  admin actions, `$wpdb->prepare` on queries, escaping on output.
- Run `phpcs`/`phpstan` (Drupal) on a checkout to confirm at the tooling level.

### 6. Security test — ✅ (static + logic)
- **HMAC auth:** canonical string re‑derived; distinct secret → distinct
  signature confirmed. Drupal `SignedRequestAccessCheckTest` covers
  valid/wrong/stale/unsigned; WordPress uses the same verified algorithm.
- **URL ownership:** `owns_url` = prefix match (path **and** domain markets) —
  Drupal `MarketRegistryTest` + `SecurityTest`; WordPress `Hrefl_Markets`
  mirrors it.
- **CSV formula injection:** Drupal `SecurityTest` asserts `=`/`+`/`-`/`@` cells
  are neutralized.
- **SSRF allowlist:** foreign host rejected before any fetch; private/reserved
  IPs blocked (`FILTER_FLAG_NO_PRIV_RANGE`) — Drupal `TargetValidator` +
  `SecurityTest`; WordPress `Hrefl_Target_Validator` mirrors it.

### 7. Performance test — ✅ (structural)
- **Verified guarantee:** the render/emit path does **not** depend on the hub
  client on either platform — confirmed by inspection:
  Drupal `HreflangEmitter` (no `HubClient`), WordPress `Hrefl_Emitter`
  (no `Hub_Client`). Page output reads only the indexed local store.
- Latency/CWV/sitemap‑at‑scale numbers require staging measurement per
  `PERFORMANCE‑TEST‑PLAN.md`.

## Runtime commands

**Drupal** (on a Drupal 10.3/11 site with the module in place):
```
composer install
drush en hrefl_client hrefl_hub && drush updatedb
vendor/bin/phpunit web/modules/custom/hrefl
phpcs --standard=Drupal,DrupalPractice web/modules/custom/hrefl
```

**WordPress** (unit suite is standalone — no WP install needed):
```
cd wordpress/hrefl-wp
composer require --dev phpunit/phpunit
vendor/bin/phpunit
```
DB/REST‑dependent WordPress behaviour (registry, matcher, ingest/serve) is
exercised by the manual `SETUP.md` walkthrough; a WP integration test suite
(`WP_UnitTestCase`) is the documented next step.

## Verdict

Everything executable in this environment **passed** for both platforms —
structure, wiring, standards, and the core algorithm/security logic (independently
re‑derived). What remains is genuine runtime execution (PHPUnit/phpcs on Drupal,
PHPUnit on the WP unit suite) and the manual UAT/performance passes on staging.
