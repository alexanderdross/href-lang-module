# HANDOFF — hrefl project

Status snapshot for continuing in a new session. Covers the whole project: the
two modules, the website, the GitHub repos, CI, and open items.

## The product

**hrefl** — cross-site `hreflang` for a family of independent country sites: a
**client** on every site + a **hub** on one, connected by an HMAC-signed API.
Emits reciprocal hreflang tags, a multilingual sitemap, and a country selector.
Two independent implementations (Drupal, WordPress) + a marketing website.

## GitHub repositories

| Repo | URL | Contents | State |
|------|-----|----------|-------|
| **hrefl** | https://github.com/alexanderdross/hrefl | the Next.js website (this folder) + Cloudflare config | pushed, private |
| **href-lang-module** | https://github.com/alexanderdross/href-lang-module | `drupal/hrefl` + `wordpress/hrefl-wp` + CI | pushed, private, branch-protected |

Both are **private** under account `alexanderdross`. `gh` is authenticated there.

## Repo layout (local project, if reopened here)

```
href-langs-module/
├── CLAUDE.md · TEST-EXECUTION-REPORT.md      (project brain + test report)
├── drupal/hrefl/…            Drupal 10.3/11 module (hrefl_client + hrefl_hub)
├── wordpress/hrefl-wp/…      WordPress plugin (client + hub by role)
├── website/…                 Next.js site (THIS repo = github/…/hrefl)
├── hrefl-drupal.zip · hrefl-wordpress.zip     download artifacts
```

## Module status (both feature-complete; test suites green on real PHP in CI)

- **Drupal:** Phases 0–3 done — client (head tags, own multilingual sitemap +
  index, HTTP Link header, selector), hub (registry, signed ingest/serve,
  URL-ownership, SSRF-safe validation, tiered matching A→B→C with
  Copilot/Anthropic + translation, review queue with bulk/batch/confirm page,
  CSV round-trip incl. upload form, Monitor dashboard, Markets admin). 21 test
  files. Docs in `drupal/hrefl/docs/` (SETUP-GUIDE, QA-ASSESSMENT, UAT-PLAN,
  BEST-PRACTICES-AUDIT, SECURITY-TEST-PLAN, PERFORMANCE-TEST-PLAN). Beginner
  install: `drupal/hrefl/SETUP.md`.
- **WordPress:** self-contained plugin mirroring the core loop (signed sync,
  ownership, SSRF-safe target validation, slug matching, review queue). Standalone
  PHPUnit unit suite (Validator/Slug/Signer). Beginner install:
  `wordpress/hrefl-wp/SETUP.md`.
- **Verification:** the suites now run for real in CI on PHP 8.3 — phpcs
  **0 errors**, WordPress PHPUnit **8 tests / 27 assertions OK**, Drupal PHPUnit
  (unit+kernel on a fresh Drupal 11) **78 tests / 197 assertions OK**. That is
  86 tests / 224 assertions green; see `TEST-EXECUTION-REPORT.md`. Only the
  **manual UAT / security / perf passes** still need a running site.

## CI (on href-lang-module)

`.github/workflows/ci.yml` runs on every PR: **standards** (php -l + phpcs
Drupal/DrupalPractice), **wordpress** (PHPUnit unit suite), **drupal** (PHPUnit
unit+kernel on a fresh Drupal 11 + SQLite). **Branch protection on `main`**
requires a PR + all three checks green before merge (0 reviews needed).
The `drupal` job is the standard recipe and may need first-run tuning.

## Website status (this repo)

- **Next.js 15 (App Router) + React 19 + TS + Tailwind**, **server-side rendered
  on Cloudflare Workers** via the OpenNext adapter (`@opennextjs/cloudflare`).
  Pages: `/` (Hero + `Explore` teasers, a hub linking out), the topic pages
  `/how-it-works/`, `/features/`, `/platforms/` (→ `public/*.zip`), `/security/`,
  and `/changelog/`.
- **Redesigned homogeneous with the drossmedia sites**: Inter (`next/font`),
  steel-blue `brand` palette + slate neutrals + cool-gray ground, pill buttons,
  app-icon logo (`public/logo.svg` = hub-and-spoke) + wordmark + `for Drupal &
  WordPress` subtitle (`components/Logo.tsx`). `pnpm build` passes.

### Information architecture (changed — anchors are now pages)
- The old one-page site had How it works / Features / Platforms / Security as
  `#anchor` sections. Each is now its **own indexable URL**, so it can rank for
  its own query. The home page keeps only short teasers linking out — the full
  text lives on the sub-page only, to avoid competing with itself.
- `routes` in `site.config.ts` is the single source of truth for nav + sitemap +
  per-page metadata. This exists because the sitemap previously advertised
  `/changelog/` before the page existed (a 404 shown to Google); `routeFor()`
  now throws instead.

### Rendering (changed — no longer a static export)
- `output: 'export'` is **gone**. `next build` reports every route as
  `ƒ (Dynamic) server-rendered on demand`, enforced by
  `export const dynamic = 'force-dynamic'` in each route segment — without it
  Next would statically optimize these pages, defeating the SSR requirement.
- Verified in the real `workerd` runtime (`wrangler dev`): `/`, `/changelog/`,
  `/sitemap.xml`, `/robots.txt` all return 200 with an `x-opennext: 1` header
  (= rendered by the Worker); `og.png` and `/_next/*` come from the ASSETS
  binding. No console or runtime errors.
- **Next was upgraded 14.2.15 → 15.5.20 + React 18 → 19.** Required: the adapter
  needs `next >= 15.5.18`, and 14.2.15 also carried a published security
  vulnerability. All components are server components, so the upgrade was clean.
- `pnpm preview` runs the app in `workerd` (closer to prod than `pnpm dev`).

### Cloudflare hosting
- **Workers with a server runtime** — `wrangler.jsonc` `main` →
  `.open-next/worker.js`, `assets` → `.open-next/assets` (binding `ASSETS`),
  `nodejs_compat` flag. Deploy: `pnpm deploy`. The GH Action
  (`.github/workflows/deploy.yml`) builds via `opennextjs-cloudflare build` and
  auto-deploys on push once `CLOUDFLARE_API_TOKEN` (+ `CLOUDFLARE_ACCOUNT_ID`)
  secrets are set.
- **"workers failed"** earlier was almost certainly **auth** — run
  `wrangler login` (or set the token). The old Pages/`deploy:pages` fallback is
  **removed**: it only applied to the static export.
- **`compatibility_date` gotcha:** it must not exceed the date the pinned
  `workerd` binary supports (setting today's date broke local startup; pinned to
  `2026-07-15`). Bump it only together with `wrangler`.
- **Suggested subdomain:** `hreflang.drossmedia.de` (descriptive, matches the
  sibling product-word pattern). Alt: `hrefl.drossmedia.de`.

## Open items / next steps

1. **Deploy the website** to Cloudflare once authenticated (`wrangler login`,
   then `pnpm deploy`); point `hreflang.drossmedia.de` at it. This is the first
   real deploy of the Worker build — expect to verify SSR once live.
2. **Website polish (optional):** add a Hero "badge" pill + a steel-accent span
   on part of the headline for closer parity with the sibling heroes; decide
   light-only vs. keep dark mode.
3. ~~CI first run~~ — **done.** PR #1 merged with all three checks green; the
   `drupal` job needed four real fixes (composer `-W`, absolute SQLite path,
   module-scoped PHPUnit, separate `--group` flags).
4. **Manual UAT / security / perf passes** on a real staging site — the
   automated suites are already green in CI; these are the ones needing a human.
5. **Deferred module features** (documented): WordPress AI matching/translation,
   CSV round-trip, bulk review, health dashboard; Drupal Tier-A identity signals
   in the collector, live Tier B/C wiring, GSC integration.
