# hrefl — website

Marketing / landing site for the **hrefl** cross-site hreflang module
(Drupal + WordPress), built with **Next.js 15 (App Router) + TypeScript +
Tailwind CSS**. **Server-side rendered on Cloudflare Workers** via the
[OpenNext adapter](https://opennext.js.org/cloudflare).

Designed **homogeneous with the drossmedia product sites** (pdfviewer /
searchforge / cachewarmer): Inter font, steel-blue accent (`brand`), slate
neutrals on a cool-gray ground, rounded-full pill buttons, and an app-icon logo
(hub-and-spoke mark + wordmark + `for Drupal & WordPress` subtitle).

## Develop

```bash
pnpm install
pnpm dev        # http://localhost:3000 — Next dev server (Node)
```

## Preview in the real Workers runtime

`pnpm dev` runs in Node; production runs in `workerd`. Before deploying, preview
in the runtime you actually ship to:

```bash
pnpm preview    # opennextjs-cloudflare build && opennextjs-cloudflare preview
```

## Rendering model

Every page is **server-rendered per request in the Worker** — there is no static
export. `next build` marks the routes `ƒ (Dynamic) server-rendered on demand`:

| Route | Rendering |
|-------|-----------|
| `/` | SSR in the Worker |
| `/how-it-works/`, `/features/`, `/platforms/`, `/security/` | SSR in the Worker |
| `/changelog/` | SSR in the Worker |
| `/sitemap.xml`, `/robots.txt` | SSR in the Worker |
| `/_next/*`, `/og.png`, zips | static assets (ASSETS binding) |

This is enforced by `export const dynamic = 'force-dynamic'` in each route
segment. Without it, Next statically optimizes these pages at build time (they
have no per-request data), which would defeat the SSR requirement. SSR responses
carry an `x-opennext: 1` header — a quick way to confirm a URL is server-rendered
rather than served from assets.

Every component is a **server component** (no `'use client'` anywhere), so the
complete HTML — content, meta tags and JSON-LD — is in the initial response and
crawlers never need to run JavaScript.

## Deploy to Cloudflare Workers

```bash
pnpm dlx wrangler login     # once — authorize your Cloudflare account
pnpm deploy                 # opennextjs-cloudflare build && opennextjs-cloudflare deploy
```

`wrangler.jsonc` points `main` at `.open-next/worker.js` (the compiled Next
server) with `.open-next/assets` bound as `ASSETS`.

> **If deploy fails** ("workers failed"), it is almost always **auth**: run
> `wrangler login` first, or set `CLOUDFLARE_API_TOKEN` (Workers Scripts: Edit)
> + `CLOUDFLARE_ACCOUNT_ID`. If your account has no `workers.dev` subdomain yet,
> Wrangler will prompt to register one.

> **`compatibility_date`** must not exceed the date supported by the pinned
> `workerd` binary, or the runtime refuses to start with
> *"This Worker requires compatibility date X, but the newest date supported by
> this server binary is Y"*. Bump it only together with `wrangler`.

### Automatic deploy (GitHub Actions)
`.github/workflows/deploy.yml` builds + deploys on push to `main`. Add repo
secrets `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID` first.

### Suggested subdomain
**`hreflang.drossmedia.de`** (descriptive, matches the product-word pattern of
the sibling sites). Alternative: `hrefl.drossmedia.de`.

## SEO

**Every topic is its own indexable URL** rather than an anchor on one long page,
so each can rank for its own query. The home page carries only short teasers that
link out — the full text lives on the sub-page only, so the two never compete for
the same query (self-inflicted duplicate content).

Driven from one source of truth, `site.config.ts`, so titles, canonicals, the
nav, the sitemap and robots.txt cannot drift apart:

- `routes` in `site.config.ts` is the **single source of truth** for the nav, the
  sitemap and every page's metadata. Adding a page = add the route *and* the
  `app/<path>/page.tsx`; `routeFor()` throws if they disagree.
- Per-page `metadata` via `lib/metadata.ts` — unique titles (kept under the ~60
  char SERP limit, incl. the `· hrefl` suffix), unique descriptions,
  self-referencing canonicals, Open Graph + Twitter cards, and a 1200×630
  `og.png`. Exactly one `<h1>` per page.
- JSON-LD (`components/JsonLd.tsx`): `WebSite` + `Organization` +
  `SoftwareApplication` site-wide, plus a `BreadcrumbList` on every sub-page
  (`breadcrumbList()` in `site.config.ts`).
- `app/sitemap.ts` / `app/robots.ts` generate `/sitemap.xml` and `/robots.txt`.
  **Every URL listed in the sitemap must resolve** — add the route before adding
  the entry.

## Structure

- `app/` — App Router: `layout.tsx`, `page.tsx` (hub), the topic pages
  `how-it-works/`, `features/`, `platforms/`, `security/`, plus `changelog/`,
  `sitemap.ts`, `robots.ts`, `globals.css` + Inter via `next/font`.
- `components/` — `Nav`, `Logo`, `Hero`, `SiteWire` (connected-sites graphic),
  `Explore` (home-page teasers), `PageHeader`, `Footer`, `JsonLd`.
- `site.config.ts` — canonical URL, names, repo, author, the `routes` registry
  and `breadcrumbList()`.
- `lib/metadata.ts` — `pageMetadata(path)` for per-page metadata.
- `open-next.config.ts` / `wrangler.jsonc` — Workers build + runtime config.
- `public/` — `logo.svg`, `favicon.svg`, `og.png`, and the downloadable module
  zips (`hrefl-drupal.zip`, `hrefl-wordpress.zip`).

## Notes

- **Changelog:** `app/changelog/page.tsx` holds the release data inline. It
  records real releases only — do not invent versions or dates.
- **Downloads:** the Platforms/Footer sections link to the zips in `public/`.
  Refresh them when the modules change:
  `cp ../hrefl-drupal.zip ../hrefl-wordpress.zip public/`.
- **Fonts:** Inter via `next/font/google` (self-hosted at build; no runtime CDN).
- **Images:** `images.unoptimized` is on — the logo/favicon are plain SVG, so the
  optimizer is unused and `/_next/image` stays out of the attack surface.
- **Theme:** light + dark via `prefers-color-scheme`. The sibling drossmedia
  sites are light-only — force light if you want exact parity.
- **pnpm builds gate:** `pnpm-workspace.yaml` sets `allowBuilds: false` for
  esbuild/sharp/workerd so installs don't stop on the approval prompt.

## Open (see HANDOFF.md)

- Verify a real Cloudflare deploy once authenticated — the only blocker is the
  `CLOUDFLARE_API_TOKEN` repo secret. Until it exists the deploy step skips with
  a warning rather than failing the run.
