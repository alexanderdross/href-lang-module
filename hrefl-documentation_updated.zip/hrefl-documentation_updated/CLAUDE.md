# href-langs-module - Project Knowledge (CLAUDE.md)

> Cross-backend `hreflang` for a family of dedicated country Drupal backends.
> This file is the durable brain of the project. Read it first. Detailed design
> lives in **`drupal/hrefl/docs/`** - the single canonical doc set (it ships with the
> composer package). The root `docs/` is now just a pointer to it. Keep this file
> current when decisions change.

## 1. What this project is

A Drupal module (Drupal 10/11; a standalone WordPress plugin now also exists in
`wordpress/hrefl-wp/`, see §9) that emits
correct, reciprocal `hreflang` alternate-language annotations **across several
independent Drupal backends** that together make up one brand's international
web presence, and that feeds those same alternates into a multilingual XML
sitemap.

Origin ticket: **WFACQUIA-81 "href-lang meta-tags"** (Project *Web Forward –
Acquia*, Epic *SEO*, Story, 5 pts, Sprint *Acquia Sprint 21*). See
`drupal/hrefl/docs/SOURCE-TICKET.md`.

Requirement in one line: *as a site owner, all content is interlinked via
`hreflang` with the equivalent content on the other sites of the family, so SEO
ranking does not drop and visitors reach the correct page for their market via a
global country selector* - e.g. switching country keeps context
(`.../us/about-us` → `.../de/ueber-uns`).

## 2. The backend topology (the whole reason this is hard)

All markets live under **one hostname** (`pro.boehringer-ingelheim.com`) but are
served by **separate, independent Drupal installations**, path-prefixed:

| Path            | Backend      | Languages                    | hreflang today |
|-----------------|--------------|------------------------------|----------------|
| `/`             | Global       | en                           | none cross-site |
| `/de/`          | Germany      | de                           | none cross-site |
| `/us/`          | US           | en (US)                      | none cross-site |
| `/ca/`          | Canada       | en-CA **and** `/ca/fr/` fr-CA | native within Canada only |
| `/ca/fr/`       | (same Canada backend, French language) | fr-CA | native within Canada only |

**Key fact:** inside a *single* backend that has Drupal core multilingual
enabled (Canada), `hreflang` between `/ca/` and `/ca/fr/` works out of the box -
that backend knows about both languages. **The gap** is that Global, Germany,
US and Canada are four separate Drupal installs with **no knowledge of each
other's content**, so nothing today links `/us/about-us` ↔ `/de/ueber-uns` ↔
`/ca/about-us`. That cross-backend linking is what this module delivers.

> **v2 rethink (current):** the concept was re-centred on **automated
> multi-signal URL auto-mapping** and hardened across performance, SEO,
> security, and engineering best practice. See `drupal/hrefl/docs/CONCEPT.md` (v2),
> `drupal/hrefl/docs/AUTOMATION.md` (core), `drupal/hrefl/docs/PERFORMANCE.md`, `drupal/hrefl/docs/SECURITY.md`,
> `drupal/hrefl/docs/SEO.md`, `drupal/hrefl/docs/RECOMMENDATIONS.md`.

## 3. Chosen architecture (decisions locked with the user)

- **Central hub, hosted on the existing Global backend.** No new standalone
  service to operate. The Global site's Drupal backend acts as the central
  mapping registry ("the hub"). Chosen over peer-to-peer (N-to-N coordination
  gets ugly as markets grow) and over a pure CSV file (too manual, stale links
  are an SEO liability).
- **Auto-mapping is a tiered, multi-signal engine** (v2, the core - see
  `drupal/hrefl/docs/AUTOMATION.md`): **Tier A** deterministic (shared IDs, schema.org,
  existing hreflang, learned slug glossary) → **Tier B** cross-lingual
  **embeddings** (self-hosted preferred) → **Tier C** LLM adjudication on the
  ambiguous few. **Confidence tiers** drive auto-confirm / review / hold, and a
  **feedback loop** shrinks manual effort over time. Event-driven + reconciled,
  always async off the request path.
  - **Tier C provider - either Microsoft Copilot or the Anthropic API**,
    selectable in config; **both are fully supported** for all inference tasks
    and neither is mandated (TA decision). The provider abstraction supports two
    inference jobs: (1) **adjudication** - choose the true equivalent among
    supplied candidates or "none"; it never invents URLs; and (2) **translation**
    - translate a page's **title and URL/slug** into a target language to help
    locate/propose the equivalent page across the language sites. All AI output
    is a *proposal*; nothing goes live without human review (below).
- **No IP/geo auto-redirects - ever.** Market/language switching is
  user-initiated via a crawlable selector; hreflang informs search engines.
  Explicit product decision and SEO/performance best practice.
- **Performance is a hard constraint.** Zero cross-backend calls at render;
  pre-computed, cache-tag-invalidated alternates; sitemap-first at scale. See
  `drupal/hrefl/docs/PERFORMANCE.md`.
- **Security & governance first-class.** URL-ownership enforcement, SSRF-safe
  crawling, signed payloads, metadata-only AI via approved region-resident
  endpoints, CSV-injection-safe imports. See `drupal/hrefl/docs/SECURITY.md`.
- **Human-in-the-loop via CSV round-trip.** Editors **download a CSV** of
  proposed + existing mappings **and AI-generated translations** (titles, slugs),
  **review/correct** it, and **re-upload**. Only `confirmed` rows go live. The
  automated AI step proposes; the manual review step disposes - this human check
  of both mappings *and* translations before publish is a hard requirement.
- **Layered equivalence keying** (user chose "manual + URL-pattern +
  automated"): AI + URL/slug patterns *propose*, editors *confirm*, and every
  confirmed set shares one stable **group UUID**. Reciprocity is then guaranteed
  *by construction* because all members belong to one group.
- **Own multilingual XML sitemap generator (decision changed).** `simple_sitemap`
  in this setup only serves a **single language**, so it cannot carry the
  cross-backend, multi-language alternates this project needs. We therefore
  **generate our own multilingual sitemap** in `hrefl_client` from the local
  alternates store: a Google-conformant `urlset` with `xhtml:link` hreflang
  alternates per URL, plus **XML enhancements - `<lastmod>` and `<priority>`**
  (the AI/hub also assists with domain input processing and these enhancements).
  `metatag` may still be reused for head-tag emission. (Note: modern
  `simple_sitemap` 4.x does support within-site hreflang; the decision to build
  our own reflects the reported single-language limitation and our need for
  cross-backend control of the XML.)
- **Platform:** Drupal 10/11. Hub API kept platform-neutral. Note: the delivered
  WordPress version (`wordpress/hrefl-wp/`) is a **standalone all-WordPress**
  implementation (client + hub by role) that does **not** interoperate with the
  Drupal hub — an all-WP family uses it, an all-Drupal family uses this. (§9)

## 4. Module shape

One project, two installable submodules:

- **`hrefl_client`** - installed on **every** backend (incl. Global). Publishes
  this site's page inventory to the hub, pulls back its resolved alternates,
  injects `<link rel="alternate" hreflang="…">` into the page `<head>`,
  **generates its own multilingual XML sitemap** (`xhtml:link` alternates +
  `lastmod` + `priority`) from the local store, and feeds the
  **country/language dropdown** (a frontend block + headless JSON feed) for
  context-preserving market switching.
- **`hrefl_hub`** - installed on the **Global** backend only. Stores the
  translation-group registry, runs the AI proposer/translator (Copilot or
  Anthropic, selectable),
  handles the CSV export/review/import loop, and serves each backend its
  resolved, reciprocal alternates.

## 5. Non-negotiable correctness rules (SEO)

These are enforced by the module; full detail in `drupal/hrefl/docs/HREFLANG-RULES.md`.

1. **Absolute, fully-qualified URLs** (`https://…`), never relative or
   protocol-relative.
2. **Reciprocal / return tags** - X links Y ⇒ Y links X. Guaranteed by the
   shared-group model.
3. **Self-referencing** - every page lists itself among the alternates.
4. **Valid codes** - ISO 639-1 language + optional ISO 3166-1 alpha-2 region
   (`de`, `en-US`, `fr-CA`); exactly one `x-default` per group.
5. **Only clean targets** - emit alternates only for indexable, canonical,
   HTTP 200 URLs; never point at redirects, 404s, or noindex pages.
6. **Safe degradation** - if no confirmed mapping exists, emit only the safe
   subset (self + within-site translations); never guess live links.

## 6. Compliance / data-governance note (important for BI, pharma)

Sending page content to an external LLM API is a data-governance decision.
Default the AI matcher to **titles, meta descriptions, headings, breadcrumbs and
sitemap structure only** (not full body), and support **enterprise/approved
endpoints** for both providers. The origin ticket explicitly floated a "local
ChatGPT instance" for this reason. Treat provider endpoints, key storage
(Drupal `key` module) and data scope as review items, not defaults.

## 7. Docs index

- `drupal/hrefl/docs/SETUP-GUIDE.md` - **plain-language setup & configuration guide**
  for non-technical admins/editors (install, hub/client config, markets, review).
- `drupal/hrefl/docs/QA-ASSESSMENT.md` - test strategy, coverage inventory, exit criteria.
- `drupal/hrefl/docs/UAT-PLAN.md` - manual end-to-end acceptance scenarios (P1/P2/P3).
- `drupal/hrefl/docs/BEST-PRACTICES-AUDIT.md` - PHP/Drupal standards self-audit + fixes.
- `drupal/hrefl/docs/SECURITY-TEST-PLAN.md` - security test cases mapped to controls.
- `drupal/hrefl/docs/PERFORMANCE-TEST-PLAN.md` - performance budget + structural guards.
- `drupal/hrefl/docs/CONCEPT.md` - **(v2)** the rethought concept and the four lenses.
- `drupal/hrefl/docs/AUTOMATION.md` - **the core:** tiered multi-signal auto-mapping engine.
- `drupal/hrefl/docs/PERFORMANCE.md` - web-performance constraints and budget.
- `drupal/hrefl/docs/SECURITY.md` - security model + AI data governance.
- `drupal/hrefl/docs/SEO.md` - broader SEO playbook (superset of the rules).
- `drupal/hrefl/docs/HREFLANG-RULES.md` - the exact enforced rules + code-mapping table.
- `drupal/hrefl/docs/ARCHITECTURE.md` - subsystems, data flow, engine, own sitemap generator.
- `drupal/hrefl/docs/DATA-MODEL.md` - group model, signals, hub API, CSV, glossary/embeddings.
- `drupal/hrefl/docs/RECOMMENDATIONS.md` - further additions/changes + TA decisions.
- `drupal/hrefl/docs/TA-DECISIONS.md` - one-pager of the decisions gating the build.
- `drupal/hrefl/docs/MONETIZATION.md` - **(future)** freemium/premium tiers, Stripe + license
  keys, GPL/open-core realities. Design guardrail only; not built initially.
- `drupal/hrefl/docs/ROADMAP.md` - phased delivery (POC → hub → engine → sitemap → WordPress).
- `drupal/hrefl/docs/SOURCE-TICKET.md` - the WFACQUIA-81 requirement as received.
- `drupal/hrefl/docs/architecture-diagram.html` / `.png` - the rendered architecture diagram.

## 7a. Consumers of the resolved mapping

The confirmed alternates in each backend's local store feed **three** consumers,
all from one source of truth: (1) `<head>` hreflang tags, (2) the module's **own
multilingual XML sitemap** (`xhtml:link` alternates + `lastmod` + `priority`;
simple_sitemap is single-language here and not used for this), and (3) the
**country/language dropdown** frontend component (context-preserving switch to
the equivalent page; also exposed as a headless JSON feed).

## 8. Decisions locked / open questions

**Locked (latest TA input):**

- **AI provider = Microsoft Copilot OR Anthropic API**, selectable in config;
  both fully supported for all inference (adjudication *and* translation of
  titles/URLs), neither mandated. (§3)
- **Sitemap = our own multilingual generator** in `hrefl_client`; simple_sitemap
  is single-language here and not relied on. XML enhancements `lastmod` +
  `priority` included. (§3, §7a)
- **AI translates titles + URLs and proposes mappings; humans review both the
  mappings and the translations before publish** - automated propose, manual
  dispose. (§3)

**Still open:**

- **Cross-domain or path-prefix only?** The "bi-family"/BICOM reference suggests
  separate domains/brands may be in scope - this drives the security model and
  onboarding. (See `drupal/hrefl/docs/RECOMMENDATIONS.md` §B.)
- **Fallback/partial-mapping policy** when no exact equivalent exists.
- **Auto-confirm at launch**, or review-everything first then relax thresholds?
- Exact hreflang code per market (`/de/` → `de` vs `de-DE`; Global `en` +
  `x-default` or `x-default` only). Draft table in `drupal/hrefl/docs/HREFLANG-RULES.md`.
- **Approved AI endpoint (region-resident) + data scope** for BI governance;
  embedding model (self-hosted?); regulated-content classification. (Provider
  *choice* is settled - both supported, selectable; only endpoint approval is
  open.)
- Hub auth model between backends (service accounts / signed / mTLS).
- How new markets (and domains) onboard.

Full list of further improvements and decisions: `drupal/hrefl/docs/RECOMMENDATIONS.md`.

## 9. Repositories, website & handoff (current state)

The project now ships **three deliverables** in this repo:

- `drupal/hrefl/` — the Drupal 10.3/11 module (client + hub submodules).
- `wordpress/hrefl-wp/` — the standalone WordPress plugin (client + hub by role).
- `website/` — a Next.js marketing site, redesigned homogeneous with the
  drossmedia product sites (Inter, steel-blue `brand` palette, app-icon logo).

Installable zips at the repo root: `hrefl-drupal.zip`, `hrefl-wordpress.zip`
(also copied into `website/public/` as downloads).

**GitHub (private, account `alexanderdross`):**
- `hrefl` → https://github.com/alexanderdross/hrefl — the **website** + Cloudflare
  config (Workers with a **server runtime** via the OpenNext adapter;
  `pnpm deploy`. The old static-export/Pages fallback is gone).
- `href-lang-module` → https://github.com/alexanderdross/href-lang-module — both
  **modules** in `drupal/` + `wordpress/` subfolders, with CI
  (`standards` + `wordpress` + `drupal` PHPUnit) and branch protection requiring
  the checks + a PR before merging to `main`.

**Suggested website subdomain:** `hreflang.drossmedia.de`.

**Website:** Next.js 15 + React 19, **server-side rendered on Cloudflare Workers**
via the OpenNext adapter (`@opennextjs/cloudflare`) — not a static export. Pages:
`/` (hub with teasers), `/how-it-works/`, `/features/`, `/platforms/`,
`/security/`, `/changelog/`; each topic is its own indexable URL, with the full
text only on the sub-page (no duplicate content against the home page). The
`routes` registry in `website/site.config.ts` is the single source of truth for
nav + sitemap + per-page metadata.

**Test status:** the suites are green on real PHP in CI — phpcs 0 errors,
WordPress 8 tests, Drupal 78 tests (unit+kernel on Drupal 11); 86 tests /
224 assertions total. See `TEST-EXECUTION-REPORT.md`.

**Open / next steps** are tracked in `website/HANDOFF.md`. The one blocker:
the Cloudflare deploy needs the `CLOUDFLARE_API_TOKEN` repo secret — everything
before it (install, Worker build) is green; the deploy step skips with a warning
until the secret exists. Also open: manual UAT/security/perf passes on a staging
site, and the deferred module features.
