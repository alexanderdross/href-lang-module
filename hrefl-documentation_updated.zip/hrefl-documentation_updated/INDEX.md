# hrefl — documentation bundle

Everything written about **hrefl**, the cross-site `hreflang` module for Drupal
and WordPress. Generated from the repository, so this is the same text the code
ships with — not a separate copy that can rot.

## Start here

| If you want to… | Read |
|---|---|
| Understand the problem and the shape of the solution | [`drupal/docs/CONCEPT.md`](drupal/docs/CONCEPT.md) |
| See it on one page | [`drupal/docs/architecture-diagram.png`](drupal/docs/architecture-diagram.png) |
| Install it without being a developer | [`drupal/docs/SETUP-GUIDE.md`](drupal/docs/SETUP-GUIDE.md) |
| Get the whole project context in one file | [`CLAUDE.md`](CLAUDE.md) |
| Know what is decided and what is still open | [`drupal/docs/TA-DECISIONS.md`](drupal/docs/TA-DECISIONS.md) |

## What is in here

**Concept & design** — `drupal/docs/`
- `CONCEPT.md` — the concept (v2) and the four lenses it is held against.
- `ARCHITECTURE.md` — subsystems, data flow, the engine, the sitemap generator.
- `AUTOMATION.md` — the core: the tiered, multi-signal auto-mapping engine.
- `DATA-MODEL.md` — group model, signals, hub API, CSV, glossary, embeddings.
- `HREFLANG-RULES.md` — the exact rules the module enforces.
- `PERFORMANCE.md` · `SECURITY.md` · `SEO.md` — the non-functional constraints.
- `ROADMAP.md` — phased delivery. `RECOMMENDATIONS.md` — further changes.
- `TA-DECISIONS.md` — the decisions gating the build.
- `MONETIZATION.md` — a future, design-guardrail-only note. Nothing is built.
- `SOURCE-TICKET.md` — the original requirement (WFACQUIA-81).
- `architecture-diagram.html` / `.png` — the diagram. **The HTML is the source**;
  the PNG is rendered from it (`tools/render_diagram.py` in the repo).

**Install & operate**
- `drupal/docs/SETUP-GUIDE.md` — plain-language guide for admins/editors.
- `drupal/SETUP.md` · `wordpress/SETUP.md` — beginner install steps per platform.
- `drupal/README.md` · `wordpress/README.md` — what each package is and does.

**Quality** — `drupal/docs/`
- `QA-ASSESSMENT.md` — test strategy, coverage inventory, exit criteria.
- `UAT-PLAN.md` — manual acceptance scenarios (P1/P2/P3).
- `BEST-PRACTICES-AUDIT.md` — PHP/Drupal standards self-audit.
- `SECURITY-TEST-PLAN.md` · `PERFORMANCE-TEST-PLAN.md` — test cases + budget.
- `TEST-EXECUTION-REPORT.md` (root) — what has actually been run, and where.

**Website** — `website/`
- `README.md` — the marketing site: SSR on Cloudflare Workers, its SEO model.
- `HANDOFF.md` — full project status snapshot and open items.

**Word versions** — `word/`
The same documents as `.docx` for stakeholders who read Word. These are
**derived** from the markdown — edit the markdown, then regenerate
(`tools/md2docx.py` in the repo). Do not edit the `.docx` by hand; the next
regeneration overwrites it.

The original client ticket file (`WFACQUIA-81.doc`) is intentionally **not** in
this bundle — it is the customer's own document. `drupal/docs/SOURCE-TICKET.md`
records the requirement as it applies here.

## Two things worth knowing

- **The markdown is the source of truth.** The `.docx` files and the diagram PNG
  are generated artifacts. If they ever disagree with the markdown, the markdown
  wins and the artifact needs regenerating.
- **AI is optional.** The engine ships a complete, usable configuration with
  deterministic matching plus human review; the AI tiers reduce manual effort,
  they are not a prerequisite. Nothing goes live without a human confirming it.
